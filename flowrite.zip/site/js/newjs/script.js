$(document).ready(function(){  

  $('.home-feature-cat').bxSlider();
  $('.bxslider-hmecat').bxSlider(); 
  $('.hme-client-bxslider').bxSlider({  auto: true });
  $('.abt-slider').bxSlider();
  $('.pt_title').css('color','red');
});
