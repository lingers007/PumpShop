function ws_fade(b,a){var c=jQuery;a.each(function(d){if(!d){c(this).show()}else{c(this).hide()}});this.go=function(d,e){c(a.get(d)).fadeIn(b.duration);c(a.get(e)).fadeOut(b.duration);return d}};// -----------------------------------------------------------------------------------
//***********************************************
//jQuery("#slider-container1").Slider({effect:"fade",prev:"",next:"",duration:38*100,delay:40*100,outWidth:808,outHeight:250,width:808,height:250,autoPlay:true,stopOnHover:false,loop:false,bullets:0,caption:false,controls:true});
